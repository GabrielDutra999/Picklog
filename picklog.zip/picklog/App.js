import React, { useState, useEffect } from 'react';
import {View, Text,TextInput,TouchableOpacity,FlatList,ImageBackground,Image, Alert,}
from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const colors = {
  background: '#DFDDDC',
  primary: '#DC5D07',
  secondary: '#DB6D1C',
  text: '#242423',
  accent: '#7EABE6',
  card: '#C6CEDC'
};

const ApresentacaoScreen = ({ continuar }) => {
  return (
    <ImageBackground
      source={require('./assets/Picking_img.jpg')}
      style={{ flex: 1 }}
      resizeMode="cover"
    >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <View style={{ padding: 20, backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: 10 }}>
          <Image
            source={require('./assets/logo1-removebg-preview.png')}
            style={{ width: 350, height: 150, marginBottom: 20 }}
            resizeMode="contain"
          />
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: colors.text, marginBottom: 10 }}>
            Quem Somos
          </Text>
          <Text style={{ fontSize: 16, color: colors.text, marginBottom: 20 }}>
            Somos uma solução voltada para pequenos comerciantes e centros de distribuição que precisam otimizar o tempo e reduzir falhas humanas no processo de separação de pedidos.
          </Text>
          <TouchableOpacity onPress={continuar} style={{ backgroundColor: colors.primary, padding: 10, borderRadius: 10 }}>
            <Text style={{ color: '#fff' }}>Começar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

const RedefinirSenhaScreen = ({ voltar }) => {
  const [email, setEmail] = useState('');
  const [novaSenha, setNovaSenha] = useState('');

  const redefinirSenha = async () => {
    if (!email || !novaSenha) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }

    try {
      const data = await AsyncStorage.getItem('usuarios');
      let usuarios = data ? JSON.parse(data) : [];
      const index = usuarios.findIndex(u => u.email === email);

      if (index !== -1) {
        usuarios[index].senha = novaSenha;
        await AsyncStorage.setItem('usuarios', JSON.stringify(usuarios));
        Alert.alert('Sucesso', 'Senha redefinida com sucesso!');
        voltar();
      } else {
        Alert.alert('Erro', 'Email não encontrado.');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao tentar redefinir a senha.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, color: colors.text, marginBottom: 20 }}>Redefinir Senha</Text>
      <TextInput
        placeholder="Email cadastrado"
        value={email}
        onChangeText={setEmail}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Nova senha"
        secureTextEntry
        value={novaSenha}
        onChangeText={setNovaSenha}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 20 }}
      />
      <TouchableOpacity onPress={redefinirSenha} style={{ backgroundColor: colors.accent, padding: 10, borderRadius: 10 }}>
        <Text style={{ color: '#fff' }}>Redefinir</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={voltar} style={{ marginTop: 10 }}>
        <Text style={{ color: colors.primary }}>Voltar</Text>
      </TouchableOpacity>
    </View>
  );
};

const LoginScreen = ({ onLogin, trocarTela, redefinirSenha }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = async () => {
    if (!email || !senha) {
      alert('Por favor, preencha email e senha.');
      return;
    }

    try {
      const data = await AsyncStorage.getItem('usuarios');
      const usuarios = data ? JSON.parse(data) : [];

      // Procura usuário com email e senha corretos
      const usuarioValido = usuarios.find(u => u.email === email && u.senha === senha);

      if (usuarioValido) {
        // Salva o nome no AsyncStorage para persistência
        await AsyncStorage.setItem('username', usuarioValido.nome);
        onLogin(usuarioValido.nome);
      } else {
        alert('Email ou senha inválidos.');
      }
    } catch (error) {
      alert('Erro ao tentar logar.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, color: colors.text, marginBottom: 20 }}>Login</Text>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 20 }}
      />
      <TouchableOpacity onPress={handleLogin} style={{ backgroundColor: colors.primary, padding: 10, borderRadius: 10, marginBottom: 10 }}>
        <Text style={{ color: '#fff' }}>Entrar</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={redefinirSenha}>
        <Text style={{ color: colors.accent }}>Esqueci a senha</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={trocarTela} style={{ marginTop: 10 }}>
        <Text style={{ color: colors.accent }}>Criar uma conta</Text>
      </TouchableOpacity>
    </View>
  );
};

const CadastroScreen = ({ trocarTela }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [nome, setNome] = useState('');

  const handleCadastro = async () => {
    if (!email || !senha || !nome) {
      alert('Preencha todos os campos.');
      return;
    }

    try {
      const data = await AsyncStorage.getItem('usuarios');
      const usuarios = data ? JSON.parse(data) : [];

      const existe = usuarios.some(u => u.email === email);
      if (existe) {
        alert('Email já cadastrado.');
        return;
      }

      usuarios.push({ email, senha, nome });
      await AsyncStorage.setItem('usuarios', JSON.stringify(usuarios));
      alert('Conta criada com sucesso!');
      trocarTela();
    } catch (error) {
      alert('Erro ao salvar dados de cadastro.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, color: colors.text, marginBottom: 20 }}>Criar Conta</Text>
      <TextInput
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{ backgroundColor: colors.card, padding: 10, width: '80%', borderRadius: 10, marginBottom: 20 }}
      />
      <TouchableOpacity onPress={handleCadastro} style={{ backgroundColor: colors.secondary, padding: 10, borderRadius: 10, marginBottom: 10 }}>
        <Text style={{ color: '#fff' }}>Cadastrar</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={trocarTela}>
        <Text style={{ color: colors.accent }}>Voltar ao login</Text>
      </TouchableOpacity>
    </View>
  );
};

const PedidoItem = ({ item }) => (
  <View style={{ backgroundColor: colors.card, padding: 10, marginVertical: 5, borderRadius: 10 }}>
    <Text style={{ color: colors.text }}>Pedido: {item.id}</Text>
    <Text style={{ color: colors.text }}>Código: {item.codigo}</Text>
    <Text style={{ color: colors.text }}>Item: {item.nome}</Text>
    <Text style={{ color: colors.text }}>Quantidade: {item.qtd}</Text>
  </View>
);

const PedidoScreen = ({ username }) => {
  const [pedidos] = useState([
    { id: '001', codigo: '2917192', nome: 'Produto A', qtd: 3 },
    { id: '002', codigo: '8736209', nome: 'Produto B', qtd: 1 },
    { id: '003', codigo: '1729384', nome: 'Produto C', qtd: 5 },
    { id: '004', codigo: '3849201', nome: 'Produto D', qtd: 2 },
    { id: '005', codigo: '7643108', nome: 'Produto E', qtd: 4 },
    { id: '006', codigo: '9182736', nome: 'Produto F', qtd: 6 },
    { id: '007', codigo: '5647382', nome: 'Produto G', qtd: 3 },
    { id: '008', codigo: '8374659', nome: 'Produto H', qtd: 7 },
    { id: '009', codigo: '2039485', nome: 'Produto I', qtd: 2 },
    { id: '010', codigo: '6655443', nome: 'Produto J', qtd: 1 }
  ]);

  const [codigoBusca, setCodigoBusca] = useState('');
  const [resultadoBusca, setResultadoBusca] = useState(null);

  const buscarPedido = () => {
    const resultado = pedidos.find(p => p.codigo === codigoBusca);
    setResultadoBusca(resultado || null);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, padding: 20 }}>
      <Text style={{ fontSize: 20, color: colors.secondary, marginBottom: 10 }}>Olá, {username}</Text>
      <Text style={{ fontSize: 18, color: colors.text, marginBottom: 10 }}>Controle de Pedidos</Text>

      <TextInput
        placeholder="Digite o código do item"
        value={codigoBusca}
        onChangeText={setCodigoBusca}
        style={{ backgroundColor: colors.card, padding: 10, borderRadius: 10, marginBottom: 10 }}
      />
      <TouchableOpacity onPress={buscarPedido} style={{ backgroundColor: colors.primary, padding: 10, borderRadius: 10, marginBottom: 20 }}>
        <Text style={{ color: '#fff' }}>Buscar</Text>
      </TouchableOpacity>

      {resultadoBusca ? (
        <View style={{ backgroundColor: colors.accent, padding: 15, borderRadius: 10 }}>
          <Text style={{ color: '#fff' }}>Pedido encontrado:</Text>
          <Text style={{ color: '#fff' }}>ID: {resultadoBusca.id}</Text>
          <Text style={{ color: '#fff' }}>Nome: {resultadoBusca.nome}</Text>
          <Text style={{ color: '#fff' }}>Quantidade: {resultadoBusca.qtd}</Text>
        </View>
      ) : codigoBusca.length > 0 ? (
        <Text style={{ color: colors.primary }}>Nenhum pedido encontrado.</Text>
      ) : null}

      <FlatList
        data={pedidos}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <PedidoItem item={item} />}
        style={{ marginTop: 20 }}
      />
    </View>
  );
};

export default function App() {
  const [telaAtual, setTelaAtual] = useState('apresentacao');
  const [usuarioLogado, setUsuarioLogado] = useState(null);

  useEffect(() => {
    const verificarLoginSalvo = async () => {
      const nome = await AsyncStorage.getItem('username');
      if (nome) {
        setUsuarioLogado(nome);
        setTelaAtual('pedido'); // Redireciona se já estiver logado
      }
    };

    verificarLoginSalvo();
  }, []);

  const handleLogin = (nome) => {
    setUsuarioLogado(nome);
    setTelaAtual('pedido');
  };

  const handleLogout = async () => {
    await AsyncStorage.removeItem('username');
    setUsuarioLogado(null);
    setTelaAtual('login');
  };

  const trocarTela = () => {
    if (telaAtual === 'login') setTelaAtual('cadastro');
    else setTelaAtual('login');
  };

  const iniciarApp = () => setTelaAtual('login');

  const abrirRedefinirSenha = () => setTelaAtual('redefinir');

  if (usuarioLogado && telaAtual === 'pedido') {
    return (
      <View style={{ flex: 1 }}>
        <PedidoScreen username={usuarioLogado} />
        <TouchableOpacity
          onPress={handleLogout}
          style={{ backgroundColor: colors.primary, padding: 10, alignItems: 'center' }}
        >
          <Text style={{ color: '#fff' }}>Sair</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'apresentacao') {
    return <ApresentacaoScreen continuar={iniciarApp} />;
  } else if (telaAtual === 'login') {
    return <LoginScreen onLogin={handleLogin} trocarTela={trocarTela} redefinirSenha={abrirRedefinirSenha} />;
  } else if (telaAtual === 'cadastro') {
    return <CadastroScreen trocarTela={trocarTela} />;
  } else if (telaAtual === 'redefinir') {
    return <RedefinirSenhaScreen voltar={() => setTelaAtual('login')} />;
  }

  return null;
}